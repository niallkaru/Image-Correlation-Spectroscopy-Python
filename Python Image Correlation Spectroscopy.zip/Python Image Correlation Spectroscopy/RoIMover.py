# -*- coding: utf-8 -*-
"""
Created on Mon May 29 14:23:57 2023

@author: niall
Quick code to take RoIs from one folder and add them to another (e.g. place 
all RoIs for one mutant into one folder so that machine learning can use it)
"""
from tkinter.filedialog import askdirectory
import os
from pathlib import Path
import shutil
import glob

first_folder = askdirectory(title="Folder with cells")
channel_1 = os.path.join(first_folder,'Collated_Channel_1')
channel_2 = os.path.join(first_folder,'Collated_Channel_2')
os.mkdir(channel_1)
os.mkdir(channel_2)
for direc in os.listdir(first_folder):
    folder_path = os.path.join(first_folder,direc)
    folder_name = os.path.basename(os.path.splitext(folder_path)[0])
    print(f'Image: {folder_name}')
    subfolder_a = os.path.join(folder_path,"Channel 1")
    subfolder_b = os.path.join(folder_path,"Channel 2")
    for file in glob.glob(os.path.join(subfolder_a,'*.tif')):
        name_full = os.path.splitext(file)[0]
        name_part = os.path.basename(name_full)
        print(f'{name_part}')
        new_name_part = str(folder_name+'__channel_1__'+name_part)
        new_name = os.path.join(channel_1,new_name_part)
        shutil.copy2(file,new_name+'.tif')
    for file in glob.glob(os.path.join(subfolder_b,'*.tif')):
        name_full = os.path.splitext(file)[0]
        name_part = os.path.basename(name_full)
        print(f'{name_part}')
        new_name_part = str(folder_name+'__channel_2__'+name_part)
        new_name = os.path.join(channel_2,new_name_part)
        shutil.copy2(file,new_name+'.tif')
                