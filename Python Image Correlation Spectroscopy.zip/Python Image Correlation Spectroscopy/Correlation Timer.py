# -*- coding: utf-8 -*-
"""
Created on Mon Jul 10 13:02:47 2023

@author: niall
"""

import numpy as np
import ics
import time
import javabridge
import bioformats
from tkinter.filedialog import askdirectory, askopenfilename
import matplotlib.pyplot as plt
from matplotlib.pyplot import figure
myloglevel = "ERROR"  # user string argument for logLevel.

javabridge.start_vm(class_path=bioformats.JARS)  # Start the virtual machine
# The following four lines stop the virtual machine from spitting out
# a huge amount of debugging info into the console, comment them out or delete if you want this
rootLoggerName = javabridge.get_static_field(
    "org/slf4j/Logger", "ROOT_LOGGER_NAME", "Ljava/lang/String;")
rootLogger = javabridge.static_call(
    "org/slf4j/LoggerFactory", "getLogger", "(Ljava/lang/String;)Lorg/slf4j/Logger;", rootLoggerName)
logLevel = javabridge.get_static_field(
    "ch/qos/logback/classic/Level", myloglevel, "Lch/qos/logback/classic/Level;")
javabridge.call(rootLogger, "setLevel",
                "(Lch/qos/logback/classic/Level;)V", logLevel)

folder_ch1 = askopenfilename(
    title="Please select the file to be opened (channel 1)")
folder_ch2 = askopenfilename(
    title="Please select the file to be opened (channel 2)")

ims_oir_ch1 = [bioformats.load_image(folder_ch1, z=0, rescale=False)]
ims_oir_ch2 = [bioformats.load_image(folder_ch2, z=0, rescale=False)]
im1 = ims_oir_ch1[0]
im2 = ims_oir_ch2[0]
start = time.time()
gii_brute = ics.brute_cross_correlation(im1, im2)
end = time.time()
print(f'Time taken brute = {end-start} s')
plt.pcolormesh(gii_brute)
plt.show()
start = time.time()


gii_fft = ics.correlation_function(im1, im2)
end = time.time()
print(f'Time taken FFT = {end-start} s')
plt.pcolormesh(gii_fft)
plt.show()