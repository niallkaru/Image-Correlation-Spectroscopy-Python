
import numpy as np
import matplotlib.pyplot as plt
from tkinter.filedialog import askopenfilename
# Sample data for the box plot

# Create a figure and axis
data0=[]
data1=[]
data2=[]
data3=[]
data4=[]
# with open(askopenfilename(title="select txt"),'r') as file0:
#      for line in file0.read().split('\n'):
#          if line:       
#              data0.append(float(line))
with open(askopenfilename(title="select txt"),'r') as file1:
     for line in file1.read().split('\n'):
         if line:       
             data1.append(float(line))
with open(askopenfilename(title="select txt"),'r') as file2:
     for line in file2.read().split('\n'):
         if line:          
             data2.append(float(line))
# with open(askopenfilename(title="select txt"),'r') as file3:
#      for line in file3.read().split('\n'):
#          if line:          
#              data3.append(float(line))
# with open(askopenfilename(title="select txt"),'r') as file4:
#      for line in file4.read().split('\n'):
#          if line:          
#              data4.append(float(line))
data = [data1,data2]#,data3,data4]
# Create the box plot
fig, ax = plt.subplots()
ax.boxplot(data)

# Set labels and title
ax.set_xticklabels(['HP1a','53BP1'])

ax.set_ylabel('Number Foci Ch1')
#ax.set_title('Box Plot Example')

# Display the plot
plt.show()