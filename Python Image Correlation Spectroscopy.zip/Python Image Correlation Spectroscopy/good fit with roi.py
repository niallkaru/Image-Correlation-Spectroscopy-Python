import numpy as np
from scipy.optimize import curve_fit
import scipy.stats as stats
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import tkinter as tk
from tkinter import filedialog

# Define the objective function
def objective_function(xy, g00, omega_o, g_inf):
    xi, eta = xy
    return g00 * np.exp(-(xi**2 + eta**2) / omega_o**2) + g_inf

# Generate example data approximating a Gaussian
x = np.linspace(-1, 1, 64)
y = np.linspace(-1, 1, 64)
x, y = np.meshgrid(x, y)

# Create a Tkinter root window
root = tk.Tk()
root.withdraw()

# Prompt the user to select a .npy file using a file dialog
file_path = filedialog.askopenfilename(filetypes=[("NumPy Array", "*.npy")])

# Load the array from the .npy file
data = np.load(file_path)

# Ensure the loaded array is of shape (64, 64)
if data.shape == (64, 64):
    print("Array loaded successfully.")
else:
    print("Error: Invalid array shape. Expected (64, 64).")
def fit_to_gaussian_roi(data):
    # Create xi and eta arrays
    d1,d2 = data.shape
    xi = np.linspace(-1, 1, d1)
    eta = np.linspace(-1, 1, d2)
    xi, eta = np.meshgrid(xi, eta)
    
    # Find the Gaussian centroid
    centroid_indices = np.unravel_index(np.argmax(data), data.shape)
    centroid_x, centroid_y = centroid_indices
    
    # Define the size of the ROI around the centroid
    roi_radius = 10  # Adjust the radius as needed
    
    # Create a mask for the region of interest (ROI)
    x_indices = np.arange(data.shape[0])
    y_indices = np.arange(data.shape[1])
    xx, yy = np.meshgrid(x_indices, y_indices)
    roi_mask = np.sqrt((xx - centroid_x)**2 + (yy - centroid_y)**2) <= roi_radius
    
    # Apply the ROI mask to the data, xi, and eta arrays
    data_roi = data[roi_mask]
    xi_roi = xi[roi_mask]
    eta_roi = eta[roi_mask]
    
    # Flatten the data and coordinates for fitting
    xi_flat = xi_roi.flatten()
    eta_flat = eta_roi.flatten()
    data_flat = data_roi.flatten()
    
    # Perform the fitting using curve_fit
    initial_guess = [data_roi.max(), 0.1, 0]  # Initial parameter guess
    params, params_covariance = curve_fit(objective_function, (xi_flat, eta_flat), data_flat, p0=initial_guess)
    
    # Extract the fitted parameters
    g00_fit, omega_o_fit, g_inf_fit = params
    
    # Print the fitted parameters
    print("Fitted g(0,0):", g00_fit)
    print("Fitted omega_o:", omega_o_fit)
    
    # Evaluate the fit
    fit_data = objective_function((xi, eta), g00_fit, omega_o_fit, g_inf_fit)
    
    # Calculate the residuals
    residuals = data - fit_data
    
    # Calculate R-squared
    total_sum_of_squares = np.sum((data - np.mean(data))**2)
    residual_sum_of_squares = np.sum(residuals**2)
    r_squared = 1 - (residual_sum_of_squares / total_sum_of_squares)
    print("R-squared:", r_squared)
    
    # # Calculate the observed and expected frequencies
    # num_bins = 10  # Number of bins for histogram
    # observed_counts, _ = np.histogram(data_flat, bins=num_bins, range=(0, num_bins-1))
    # expected_counts, _ = np.histogram(fit_data.flatten(), bins=num_bins, range=(0, num_bins-1))
    
    # # Print observed and expected frequencies for debugging
    # print("Observed frequencies:", observed_counts)
    # print("Expected frequencies:", expected_counts)
    
    # # Calculate the chi-square statistic and p-value
    # chi2, p_value = stats.chisquare(f_obs=observed_counts, f_exp=expected_counts)
    # print("Chi-square statistic:", chi2)
    # print("p-value:", p_value)
    
    # Calculate the area of the image
    px = 0.05
    image_area_px = data.shape[0] * data.shape[1]
    image_area_um = image_area_px*(px**2)
    # Calculate the estimated number of foci
    N = image_area_um / (np.pi * omega_o_fit**2 * g00_fit)
    
    print("Estimated number of foci:", N)
    
    # Plot original data, fitted data, and residuals
    fig, axes = plt.subplots(1, 3, figsize=(18, 4))
    
    # Plot original data
    axes[0].set_title('Original Data')
    im = axes[0].imshow(data, cmap='viridis', origin='lower')
    fig.colorbar(im, ax=axes[0], label='Data')
    
    # Plot fitted function
    axes[1].set_title('Fitted Function')
    im = axes[1].imshow(fit_data, cmap='viridis', origin='lower')
    fig.colorbar(im, ax=axes[1], label='Fit')
    
    # Plot residuals
    axes[2].set_title('Residuals')
    im = axes[2].imshow(residuals, cmap='bwr', origin='lower')
    fig.colorbar(im, ax=axes[2], label='Residual')
    
    # Set common labels
    for ax in axes:
        ax.set_xlabel('xi')
        ax.set_ylabel('eta')
    
    plt.tight_layout()
    plt.show()
    
    # Plot original data and fitted data in 3D
    fig_3d = plt.figure(figsize=(12, 6))
    ax3d = fig_3d.add_subplot(121, projection='3d')
    ax3d.set_title('Original Data (3D)')
    ax3d.plot_surface(x, y, data, cmap='viridis')
    ax3d.set_xlabel('x')
    ax3d.set_ylabel('y')
    
    ax3d_fit = fig_3d.add_subplot(122, projection='3d')
    ax3d_fit.set_title('Fitted Data (3D)')
    ax3d_fit.plot_surface(x, y, fit_data, cmap='viridis')
    ax3d_fit.set_xlabel('x')
    ax3d_fit.set_ylabel('y')
    plt.tight_layout()
    plt.show()
    
    # Residuals - 3D plot
    fig_3d_res = plt.figure(figsize=(12, 6))
    ax3d_res = fig_3d_res.add_subplot(212, projection='3d')
    ax3d_res.set_title('Residuals')
    ax3d_res.plot_surface(xi, eta, residuals, cmap='viridis')
    ax3d_res.set_xlabel('xi')
    ax3d_res.set_ylabel('eta')
    ax3d_res.set_zlabel('Residual')
    plt.tight_layout()
    plt.show()
