#!/usr/bin/env python3
#
# "Image Region"
# Written by Martin Sevior
# University of Melbourne
# April, 2023
# (C) Copywright University of Melbourne, 2023
#
import tkinter as tk
from tkinter import Menu
from tkinter import filedialog
import tkinter.font as tkFont

from PIL import Image, ImageTk
import os

class ImageRegion:
    def __init__(self):
        self.selection_path = ''
        self.selection_name = 'Region'
        self.image_file = 'image.jpg'
        self.selection_number = 0
        self.loop = tk.Tk()
        self.myCanvas_exists =0
        self.ROI = 64
        self.speed = 2.0
        self.start = 0
        
    def set_path(self):
        self.selection_path = filedialog.askdirectory(title="Set Output Directory")
        # print('Output directory is: ',self.selection_path)

    def on_enter(self,event):
        self.selection_name = event.widget.get()
        # print('Selection name', self.selection_name)
        self.selection_number = 0
        toplevel = event.widget.winfo_toplevel()
        toplevel.destroy()

    def params_selected(self):
        self.selection_name =  self.eRegion_name.get()
        self.selection_number = int(self.eSel_numb.get())
        self.ROI = int(self.eROI.get())
        # print(' Region Name, selection number, ROI = ',self.selection_name,self.selection_number,self.ROI)
        self.param_window.destroy()                       
    
    def set_params(self):
        self.param_window = tk.Toplevel(self.loop)
        self.param_window.title("Set Image region parameters")
        param_frame= tk.Frame(self.param_window)
        param_frame.pack(expand=True, fill='both')
    
        label0 = tk.Label(param_frame,text="Name for selected Region")
        label0.grid(row=0,column=0,padx=5,pady=5)
        self.eRegion_name = tk.Entry(param_frame)
        self.eRegion_name.insert(0,self.selection_name)
        self.eRegion_name.grid(row=0,column=1,padx=5,pady=5)

        label1 = tk.Label(param_frame,text="Current selection Number")
        label1.grid(row=1,column=0,padx=5,pady=5)
        self.eSel_numb = tk.Entry(param_frame)
        self.eSel_numb.insert(0,str(self.selection_number))
        self.eSel_numb.grid(row=1,column=1,padx=5,pady=5)

        label2 = tk.Label(param_frame,text="Number of Pixels in region")
        label2.grid(row=2,column=0,padx=5,pady=5)
        self.eROI = tk.Entry(param_frame)
        self.eROI.insert(0,str(self.ROI))
        self.eROI.grid(row=2,column=1,padx=5,pady=5)

        button = tk.Button(param_frame,text="OK",command=self.params_selected)
        button.grid(row=3,column=0,columnspan=2,padx=5,pady=5)
        self.param_window.grab_set()

    def set_name(self):
        entry_window = tk.Toplevel(self.loop)
        entry_window.title("Selection Image name")
        entry = tk.Entry(entry_window)
        entry.pack()
        #
        # bind <return> event 
        entry.bind("<Return>", self.on_enter)


    def on_image_click(self,event):
        x = self.myCanvas.canvasx(event.x)
        y = self.myCanvas.canvasy(event.y)
        roi = self.ROI/2
        # print("Clicked at x =", x, ", y =", y)
        xl = x - roi
        xh = x + roi
        yl = y - roi
        yh = y + roi
        if(xl < 0):
            xl =0
        if(xh >= self.photo.width()):
            xh = self.photo.width()
        if(yh >= self.photo.height()):
            yh = self.photo.height()
        cropped_image = self.cur_img.crop((xl, yl, xh, yh))
        cropped_photo = ImageTk.PhotoImage(cropped_image)
        pil_image = ImageTk.getimage(cropped_photo)
        sel_name = os.path.join(self.selection_path,self.selection_name)
        sel_name = sel_name + '_' + str(self.selection_number)+'.png'
        self.selection_number += 1
        pil_image.save(sel_name)
        # draw a square around the selection
        self.myCanvas.create_line(xl,yl,xh,yl,fill='yellow')
        self.myCanvas.create_line(xh,yl,xh,yh,fill='yellow')
        self.myCanvas.create_line(xh,yh,xl,yh,fill='yellow')
        self.myCanvas.create_line(xl,yh,xl,yl,fill='yellow')
        # draw the name of the region file on the canvas
        short_name = self.selection_name+'_'+str(self.selection_number)
        self.myCanvas.create_text(xl+roi,yl+10,text=short_name,font=('Arial',8),fill='yellow')
        
    def scroll_canvas(self,x,y):
        # update the position of the canvas based on the distance dragged
#        if self.start_x and self.start_y:
#            dx = self.start_x - x
#            dy = self.start_y - y
#            print('scrolling dx,dy ',dx,dy)
#            dx = int(float(dx)*self.speed)
#            dy = int(float(dy)*self.speed)
#            self.myCanvas.xview_scroll(dx,"units")
#            self.myCanvas.yview_scroll(dy,"units")
#        self.start_x = x
#        self.start_y = y
        #
        # xl,xr are the fraction of the total on the screen in x-direction
        #xl,xr = self.myCanvas.xview()
        #yl,yr = self.myCanvas.yview()
        dx =  self.speed*float(self.start_x - x)/self.cur_img.width
        dy =  self.speed*float(self.start_y - y)/self.cur_img.height
        
        self.myCanvas.xview_moveto(self.xl+dx)
        self.myCanvas.yview_moveto(self.yl+dy)
        
    def start_scroll(self,x,y):
        #
        # xl,xr are the fraction of the total on the screen in x-direction
        self.xl,xr = self.myCanvas.xview()
        self.yl,yr = self.myCanvas.yview()
        #
        # Want to use moveto to drag the window based on the delta between
        # the starting x position and the x position of the drag event
        # so we record the start x position here
        self.start_x = x
        self.start_y = y
        self.loop.config(cursor="hand2")
        
        # print('start_x, start_y = ', self.start_x, self.start_y)

    def end_scroll(self):
        self.loop.config(cursor="arrow")

        
    def get_image(self):
        if(self.start == 1):
            self.start_frame.destroy()
            self.start = 0
            
        self.image_file = filedialog.askopenfilename(title="Choose Image")
        # print('image_file is: ',self.image_file)
        self.cur_img = Image.open(self.image_file)
        self.photo = ImageTk.PhotoImage(self.cur_img)
        if(self.myCanvas_exists != 0):
            self.myCanvas.delete('all')
            self.myCanvas.create_image(0, 0, anchor=tk.NW, image=self.photo,tags=('image',))
            return
        
        # Create a canvas with the same size as the image
        
        #screen_width = self.loop.winfo_screenwidth()
        #screen_height = self.loop.winfo_screenheight()
        screen_width = 2560 # My external monitors
        screen_height = 1440 # My external monitors

        self.start_x = None
        self.start_y = None
        iwidth = self.cur_img.width
        iheight = self.cur_img.height
        # print('screen width, height = ', screen_width, screen_height)
        # print('Image width, height = ', iwidth, iheight)
    
        if(iwidth > (3*screen_width/4)):
            iwidth = 3*screen_width/4
        if(iheight > (3*screen_height/4)):
            iheight = 3*screen_height/4

        sFrame =  tk.Frame(self.loop,width=iwidth, height=iheight)
        sFrame.pack(expand=True, fill=tk.BOTH) 
        self.myCanvas = tk.Canvas(sFrame, width=iwidth, height=iheight,scrollregion=(0,0,self.cur_img.width,self.cur_img.height))
        self.myScroll = self.myCanvas.create_rectangle(0,0,self.cur_img.width,self.cur_img.height)
        self.scrollbarx = tk.Scrollbar(sFrame, orient=tk.HORIZONTAL)
        self.scrollbarx.pack(side=tk.BOTTOM, fill=tk.X)
        self.scrollbarx.config(command=self.myCanvas.xview)
        self.scrollbary = tk.Scrollbar(sFrame, orient=tk.VERTICAL)
        self.scrollbary.pack(side=tk.RIGHT, fill=tk.Y)
        self.scrollbary.config(command=self.myCanvas.yview)

        self.myCanvas.config(width=iwidth, height=iheight)
        self.myCanvas.config(xscrollcommand=self.scrollbarx.set, yscrollcommand=self.scrollbary.set)
        self.myCanvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.myCanvas.bind('<Configure>', lambda e: self.myCanvas.configure(scrollregion=self.myCanvas.bbox('all')))

        # Create an image item on the canvas
        self.myCanvas.create_image(0, 0, anchor=tk.NW, image=self.photo,tags=('image',))  

        #    frame = tk.Frame(canvas)
        #    canvas.create_window((0,0), window=frame, anchor='nw')

        # Bind the label to the on_click function
        self.myCanvas.bind("<Button-1>", self.on_image_click)
        # bind the right mouse button to the scroll function on press and release
#        self.myCanvas.bind("<Button-3>", lambda event: self.myCanvas.scan_mark(event.x, event.y))
        self.myCanvas.bind("<Button-3>", lambda event: self.start_scroll(event.x, event.y))
        self.myCanvas.bind("<B3-Motion>", lambda event: self.scroll_canvas(event.x,event.y))
        self.myCanvas.bind("<ButtonRelease-3>", lambda event: self.end_scroll())

        self.myCanvas_exists = 1

    def end_help(self):
        self.help_window.destroy()
        
    def print_help(self):
        self.help_window = tk.Toplevel(self.loop)
        self.help_window.title("Image region help")
        help_frame= tk.Frame(self.help_window)
        help_frame.pack(expand=True, fill='both')
        text_widget = tk.Text(help_frame, height=10, width=80)
        text_widget.pack(expand=True, fill=tk.BOTH)
        text_widget.insert(tk.END,' \"Left click\" selects a region around the mouse.\n \"Right drag\" moves the image with the mouse. \n \"Selection path\" allows the choice of directory for the selection regions. \n \"Region parameters\" allows choice of name, number and selection area.')
        button = tk.Button(help_frame,text="OK",command=self.end_help)
        button.pack(expand=True, fill=tk.BOTH)
        self.help_window.grab_set()

    def end_about(self):
        self.about_window.destroy()

         
    def print_about(self):
        self.about_window = tk.Toplevel(self.loop)
        self.about_window.title("Image region help")
        about_frame= tk.Frame(self.about_window)
        about_frame.pack(expand=True, fill='both')
        text_widget = tk.Text(about_frame, height=10, width=80)
        text_widget.pack(expand=True, fill=tk.BOTH)
        text_widget.insert(tk.END,' \"Image Region" \n Written by Martin Sevior \n University of Melbourne \n April, 2023 \n (C) Copyright University of Melbourne, 2023 \n')
        button = tk.Button(about_frame,text="OK",command=self.end_about)
        button.pack(expand=True, fill=tk.BOTH)
        self.about_window.grab_set()
       
    def construct_gui(self,AppName):
        self.loop.title(AppName)
        menubar = Menu(self.loop)
        self.loop.config(menu=menubar)
        file_menu = Menu(menubar, tearoff=0)
        file_menu.add_command(label="Selection Path",command=self.set_path)
        file_menu.add_command(label="Region Parameters",command=self.set_params)
        file_menu.add_command(label="Image File",command=self.get_image)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.loop.quit)
        menubar.add_cascade(label="File", menu=file_menu)
        help_menu = Menu(menubar, tearoff=0)
        help_menu.add_command(label="Help",command=self.print_help)
        help_menu.add_command(label="About",command=self.print_about)
        menubar.add_cascade(label="Help", menu=help_menu)
        #
        # start Screen
        self.start_frame= tk.Frame(self.loop)
        self.start_frame.pack(expand=True, fill='both')
        text_widget = tk.Text(self.start_frame, height=6, width=40)
        text_widget.pack(expand=True, fill=tk.BOTH)
        custom_font = tkFont.Font(family="Ariel", size=16, weight="bold")
        text_widget.config(font=custom_font)
        text_widget.insert(tk.END,' \n \n Select and save regions of an image\n Choose \"Image file" to load an image \n')
        text_widget.pack(expand=True, fill=tk.BOTH)
        self.start = 1
        
        return self.loop

    def run(self):
        self.loop.mainloop()

if __name__ == '__main__':
    myImageRegion = ImageRegion()
    myImageRegion.construct_gui('Image Region')
    myImageRegion.run()
