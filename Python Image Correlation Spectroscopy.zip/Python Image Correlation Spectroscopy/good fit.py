import numpy as np
from scipy.optimize import curve_fit
import scipy.stats as stats
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import tkinter as tk
from tkinter import filedialog

# Define the objective function
def gaussian_function(xy, g00, omega_o, g_inf):
    xi, eta = xy
    return g00 * np.exp(-(xi**2 + eta**2) / omega_o**2) + g_inf

def fit_to_gaussian(data):
    # Data is N-by-N array, a correlation function
    x = np.linspace(-1, 1, 64)
    y = np.linspace(-1, 1, 64)
    x, y = np.meshgrid(x, y)
    
    
    # Create xi and eta arrays
    xi = np.linspace(-1, 1, 64)
    eta = np.linspace(-1, 1, 64)
    xi, eta = np.meshgrid(xi, eta)
    
    # Flatten the data and coordinates for fitting
    xi_flat = xi.flatten()
    eta_flat = eta.flatten()
    data_flat = data.flatten()
    
    # Perform the fitting using curve_fit
    initial_guess = [data.max(), 0.07, 0]  # Initial parameter guess
    params, params_covariance = curve_fit(gaussian_function, (xi_flat, eta_flat), data_flat, p0=initial_guess)
    
    # Extract the fitted parameters
    g00_fit, omega_o_fit, g_inf_fit = params
    
    # Print the fitted parameters
    print("Fitted g(0,0):", g00_fit)
    print("Fitted omega_o:", omega_o_fit)
    
    # Evaluate the fit
    fit_data = gaussian_function((xi, eta), g00_fit, omega_o_fit, g_inf_fit)
    
    # Calculate the residuals
    residuals = data - fit_data
    
    # Calculate R-squared
    total_sum_of_squares = np.sum((data - np.mean(data))**2)
    residual_sum_of_squares = np.sum(residuals**2)
    r_squared = 1 - (residual_sum_of_squares / total_sum_of_squares)
    print("R-squared:", r_squared)
    
    # Calculate the chi-square statistic and p-value
    observed_frequencies, _ = np.histogram(data_flat, bins=10)  # Modify the number of bins as needed
    expected_frequencies = np.histogram(fit_data.flatten(), bins=10)[0]
    chi2, p_value = stats.chisquare(f_obs=observed_frequencies, f_exp=expected_frequencies)
    print("Chi-square statistic:", chi2)
    print("p-value:", p_value)
    
    # Calculate the area of the image
    px = 0.052
    image_area_px = data.shape[0] * data.shape[1]
    image_area_um = image_area_px*(px**2)
    # Calculate the estimated number of foci
    N = image_area_um / (np.pi * omega_o_fit**2 * g00_fit)
    
    print("Estimated number of foci:", N)
    
    # Plot original data, fitted data, and residuals
    fig, axes = plt.subplots(1, 3, figsize=(18, 4))
    
    # Plot original data
    axes[0].set_title('Original Data')
    im = axes[0].imshow(data, cmap='viridis', origin='lower')
    fig.colorbar(im, ax=axes[0], label='Data')
    
    # Plot fitted function
    axes[1].set_title('Fitted Function')
    im = axes[1].imshow(fit_data, cmap='viridis', origin='lower')
    fig.colorbar(im, ax=axes[1], label='Fit')
    
    # Plot residuals
    axes[2].set_title('Residuals')
    im = axes[2].imshow(residuals, cmap='bwr', origin='lower')
    fig.colorbar(im, ax=axes[2], label='Residual')
    
    # Set common labels
    for ax in axes:
        ax.set_xlabel('xi')
        ax.set_ylabel('eta')
    
    plt.tight_layout()
    plt.show()
    
    # Plot original data and fitted data in 3D
    fig_3d = plt.figure(figsize=(12, 6))
    ax3d = fig_3d.add_subplot(121, projection='3d')
    ax3d.set_title('Original Data (3D)')
    ax3d.plot_surface(x, y, data, cmap='viridis')
    ax3d.set_xlabel('x')
    ax3d.set_ylabel('y')
    
    ax3d_fit = fig_3d.add_subplot(122, projection='3d')
    ax3d_fit.set_title('Fitted Data (3D)')
    ax3d_fit.plot_surface(x, y, fit_data, cmap='viridis')
    ax3d_fit.set_xlabel('x')
    ax3d_fit.set_ylabel('y')
    plt.tight_layout()
    plt.show
    # Residuals - 3D plot
    fig_3d_res = plt.figure(figsize=(12, 6))
    ax3d_res = fig_3d_res.add_subplot(212, projection='3d')
    ax3d_res.set_title('Residuals')
    ax3d_res.plot_surface(xi, eta, residuals, cmap='viridis')
    ax3d_res.set_xlabel('xi')
    ax3d_res.set_ylabel('eta')
    ax3d_res.set_zlabel('Residual')
    plt.tight_layout()
    plt.show()
    return params, params_covariance, N
