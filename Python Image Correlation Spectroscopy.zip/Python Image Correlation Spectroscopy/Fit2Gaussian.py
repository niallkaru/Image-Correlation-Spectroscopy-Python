# -*- coding: utf-8 -*-
"""
Created on Tue Feb 14 10:59:11 2023

@author: niall
"""

import numpy as np
import matplotlib.pyplot as plt
import scipy.io as sp
import scipy.optimize as opt
from scipy.fft import fft2,ifft2
from utils import timeit
import ics
import matplotlib
from matplotlib.pyplot import figure
from mpl_toolkits.mplot3d import  Axes3D
import os
from tkinter import Tk
from tkinter.filedialog import askdirectory

"""" 
Retrieving correlation functions from .mat files, getting individual functions
"""
how_many = ics.fit_how_many() # Plot one or more plots (choice)
chosen_fit = ics.parameter_choice() # Choose one or two parameter fit
folder = askdirectory(title='Select Folder') # shows dialog box and return the path


for file in folder:
    mat_Gij = sp.loadmat(os.path.join(folder, 'Gij.mat'))
    Gij = mat_Gij['Gij']
    
    mat_Gji = sp.loadmat(os.path.join(folder, 'Gji.mat'))
    Gji = mat_Gji['Gji']
    
    mat_Gii = sp.loadmat(os.path.join(folder, 'Gii.mat'))
    Gii = mat_Gii['Gii']
    
    mat_Gjj = sp.loadmat(os.path.join(folder, 'Gjj.mat'))
    Gjj = mat_Gjj['Gjj']
    
## Retrieve correlation functions from folder
x,y,z = Gii.shape  # z = number of correlation functions, used in loop
"""
Fitting functions to a Gaussian
"""

## Choose whether one or two parameter fit, and whether one or all functions
if chosen_fit == "1": #i.e. one parameter


    if how_many == "1": # 1 means fit only a single function
        
    
        Gii_one = np.array(Gii[:,:,0])
        n_one = ics.fit_to_gaussian(Gii_one)
        Gjj_one = np.array(Gjj[:,:,0])
        #n_two = ics.fit_to_gaussian(Gjj_one)
        colour = 'gray'
    
    
    elif how_many == "2": # 2 means fit all functions within the array
        for ii in range(0,int(z)):
            Gii_ite = np.array(Gij[:,:,ii])
            print("Plot",{ii},"Gii")
            m_one = ics.fit_to_gaussian((Gii_ite))
            Gjj_ite = np.array(Gjj[:,:,ii])
            print("Plot" ,{ii} ,"Gjj")
            
            
        
    else:
        quit()
elif chosen_fit == "2": #i.e. two parameter fit 
    if how_many == "1": # 1 means fit only a single function
        
    
        Gii_one = np.array(Gii[:,:,0])
        n_one = ics.fit_to_gaussian2(Gii_one)
        Gjj_one = np.array(Gjj[:,:,0])
        n_two = ics.fit_to_gaussian2(Gjj_one)
        colour = 'gray'
    
    
    elif how_many == "2": # 2 means fit all functions within the array
        for ii in range(0,int(z)):
            Gii_ite = np.array(Gii[:,:,ii])
            print("Plot",{ii},"Gii")
            m_one = ics.fit_to_gaussian2((Gii_ite))
            Gjj_ite = np.array(Gjj[:,:,ii])
            print("Plot" ,{ii} ,"Gjj")
            
            
        
    else:
        quit()
else:
    quit()
