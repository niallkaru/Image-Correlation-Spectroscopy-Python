# -*- coding: utf-8 -*-
"""
Created on Thu May  4 14:27:00 2023

@author: niall
Quick code to create a folder containing an image and two subfolders for each
channel, so that it can be segmented into many RoIs
"""
from tkinter.filedialog import askdirectory
import os
from pathlib import Path
import shutil

first_folder = askdirectory(title="Folder to be subdivided")
for file in os.listdir(first_folder):
    image_path = os.path.join(first_folder,file)
    image_name = Path(image_path).stem
    print(f'Image: {image_name}')
    folder_name = os.path.join(first_folder,image_name)
    print(folder_name)
    os.mkdir(folder_name)
    subfolder_a = os.path.join(folder_name,"Channel 1")
    subfolder_b = os.path.join(folder_name,"Channel 2")
    subfolder_c = os.path.join(folder_name,"Channel 1_128")
    subfolder_d = os.path.join(folder_name,"Channel 2_128")
    subfolder_e = os.path.join(folder_name,"Channel 1_processed")
    subfolder_f = os.path.join(folder_name,"Channel 2_processed")
    os.mkdir(subfolder_a)
    os.mkdir(subfolder_b)
    os.mkdir(subfolder_c)
    os.mkdir(subfolder_d)
    os.mkdir(subfolder_e)
    os.mkdir(subfolder_f)
    shutil.move(image_path,folder_name)
    



