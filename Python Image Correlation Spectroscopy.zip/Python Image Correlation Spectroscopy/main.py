# -*- coding: utf-8 -*-
"""
Created on Wed Mar 29 15:58:52 2023

@author: niall

Main file to perform image correlation spectroscopy (ICS) on images. The code
can take in images from .oir and .tif files, but if another format is required
that is supported by bioformats it can be changed easily. 

The code can either take in raw images, or it can take in RoIs, but this must
be chosen by commenting or uncommenting lines of code.

The code will output an image of the cells (one for each channel), the 
autocorrelations for each channel and the cross-correlation between them. It 
will also output a Gaussian fit.
"""
import ics
import numpy as np
from tkinter.filedialog import askdirectory, askopenfilename
import os
import javabridge
import bioformats
import matplotlib.pyplot as plt
import glob
from pathlib import Path
"""
Parameters to use (to be edited by user)
"""
cell = str("53BP1_")


###### READING IN IMAGES AND MAKING FOLDERS ######
# %%
myloglevel = "ERROR"  # user string argument for logLevel.

javabridge.start_vm(class_path=bioformats.JARS)  # Start the virtual machine
# The following four lines stop the virtual machine from spitting out
# a huge amount of debugging info into the console, comment them out or delete if you want this
rootLoggerName = javabridge.get_static_field(
    "org/slf4j/Logger", "ROOT_LOGGER_NAME", "Ljava/lang/String;")
rootLogger = javabridge.static_call(
    "org/slf4j/LoggerFactory", "getLogger", "(Ljava/lang/String;)Lorg/slf4j/Logger;", rootLoggerName)
logLevel = javabridge.get_static_field(
    "ch/qos/logback/classic/Level", myloglevel, "Lch/qos/logback/classic/Level;")
javabridge.call(rootLogger, "setLevel",
                "(Lch/qos/logback/classic/Level;)V", logLevel)

### Finding background average ###
channel1_bkgd = r"C:\Users\niall\(not OneDrive) Storage\Cell Data\Folder for bkgd correction\149BR\XRCC4\Ch1"
channel2_bkgd = r"C:\Users\niall\(not OneDrive) Storage\Cell Data\Folder for bkgd correction\149BR\XRCC4\Ch2"

ims_bkgd_ch1 = [bioformats.load_image(
    file, z=0, rescale=False) for file in glob.glob(os.path.join(channel1_bkgd, '*.tif'))]
ims_bkgd_ch2 = [bioformats.load_image(
    file, z=0, rescale=False) for file in glob.glob(os.path.join(channel2_bkgd, '*.tif'))]
a1,a2 = ims_bkgd_ch1[0].shape
# ch1_bkgd_avg = np.mean(ims_bkgd_ch1, axis=0)
# ch2_bkgd_avg = np.mean(ims_bkgd_ch2, axis=0)
ch1__avg = np.mean(ims_bkgd_ch1)
ch2__avg = np.mean(ims_bkgd_ch2)
ch1_bkgd_avg = np.zeros((a1,a2))
ch2_bkgd_avg = np.zeros((a1,a2))
ch1_bkgd_avg[:,:] = ch1__avg
ch2_bkgd_avg[:,:] = ch2__avg
#################
# %%
# Choose what data to analyse and where to save the analysis
how_many = ics.one_or_many()
if how_many == '3':
    ####
    ACF_ii_number = []
    ACF_jj_number = []
    CCF_ij_number = []
    frac_i_ij = []
    frac_j_ij = []
    big_direc = askdirectory(title='Where is all the stuff?')

    # +str(folder_number))
    saveto = os.path.join(big_direc, 'ICS_Analysis_53BP1')

    folder_save = os.path.join(saveto, 'CFs')

    for folder in glob.glob(big_direc+"/*", recursive=True):

        print(f'\n Chosen data directory:   {folder}')
        # folder_ch1 = askdirectory(title='Select folder with data for channel 1')
        # print(f'Chosen data directory:   {folder_ch1}')
        # folder_ch2 = askdirectory(title='Select folder with data for channel 2')
        # print(f'Chosen data directory:   {folder_ch2}')
        folder_ch1 = os.path.join(folder, 'Channel 1')
        folder_ch2 = os.path.join(folder, 'Channel 2')
        # askdirectory(title='Where should the correlation functions and plots be saved?')
        savedirec = big_direc
        print(f'Folder selected:   {savedirec}')

        folder_number = 1

        print(f'Saving analysis to:   {saveto}')

        # ims_oir_ch1 = bioformats.load_image('53bp1_gh2ax_010423_1.oir',0)
        # Read in all the images with .oir or .tif file extensions
        # NOTE: If an image is in both of these formats it will be read in twice.

        ims_oir_ch1 = [bioformats.load_image(file,0) for file in glob.glob(os.path.join(folder_ch1,'*.oir'))]
        ims_oir_ch2 = [bioformats.load_image(file,1) for file in glob.glob(os.path.join(folder_ch2,'*.oir'))]
        ims_tif_ch1 = [bioformats.load_image(file, z=0, rescale=False) for file in glob.glob(os.path.join(folder_ch1, '*.tif'))]
        ims_tif_ch2 = [bioformats.load_image(file, z=0, rescale=False) for file in glob.glob(os.path.join(folder_ch2, '*.tif'))]
        # ims_tif_ch1 = [bioformats.load_image(file,t=0) for file in glob.glob(os.path.join(folder,'*.tif'))]
        # ims_tif_ch2 = [bioformats.load_image(file,t=1) for file in glob.glob(os.path.join(folder,'*.tif'))]
        # the (file,0) and (file,1) sections obtain channels 1 and 2 respectively.
        # .tif is, on occasion, read in through the time channel, hence t=0,1.

        # Add the tif images to the oir arrays
        ims_oir_ch1.extend(ims_tif_ch1)
        ims_oir_ch2.extend(ims_tif_ch2)

        made_folder_saveto = os.path.isdir(saveto)
        made_folder_folder_save = os.path.isdir(folder_save)
        if made_folder_saveto == False:
            os.mkdir(saveto)
        if made_folder_folder_save == False:
            os.mkdir(folder_save)
        N = len(ims_oir_ch1)
        M = len(ims_oir_ch2)
        if N != M:
            print(f'ERROR: The two channels do not have an equal number of images \
                  Channel 1: {N} and Channel 2: {M}')
            exit()
        else:
            print(f'The number of pairs of images is {N},{M}')
        # Display images
        for ii in range(0, int(N)):
            imgplot_oir_ch1 = plt.imshow(ims_oir_ch1[ii])
            plt.axis('off')
            plt.show()
            imgplot_oir_ch2 = plt.imshow(ims_oir_ch2[ii])
            plt.axis('off')
            plt.show()
        # %%
        # # Create lists for correlation functions and numbers of foci
        # %%
        Gii = []
        Gjj = []
        Gij = []

        #Gji = []
        # %%
        # Compute correlation functions
        # %%
        for p in range(0, int(N)):
            channel_1 = ims_oir_ch1[p] - ch1_bkgd_avg
            channel_2 = ims_oir_ch2[p] - ch2_bkgd_avg


            Gii.append(ics.correlation_function(channel_1, channel_1))
            Gjj.append(ics.correlation_function(channel_2, channel_2))
            Gij.append(ics.correlation_function(channel_1, channel_2))
            #Gji.append(ics.correlation_function(channel_2, channel_1))

        # %%

        # %%
        ### Plotting ###
        # If there is anything in the array, save the correlation functions and plot them

        if not len(Gii) == 0:

            image_name = Path(folder).stem
            print(f'Image: {image_name}')
            print("\n")
            np.save(os.path.join(folder_save, 'Gii_'+image_name), Gii)
            np.save(os.path.join(folder_save, 'Gjj_'+image_name), Gjj)
            np.save(os.path.join(folder_save, 'Gij_'+image_name), Gij)
            #np.save(os.path.join(folder_save,'Gji_'+iamge_name), Gji)
            ics.plot_ccf(folder_save, Gii, 'Gii', image_name)
            ics.plot_ccf(folder_save, Gjj, 'Gjj', image_name)
            ics.plot_ccf(folder_save, Gij, 'Gij', image_name)
            #ics.plot_ccf(folder_save, Gji,'Gji',image_name)

        ### Averaging Functions ####
        Gii_avg = np.sum(Gii, axis=0)/(len(Gii))
        Gjj_avg = np.sum(Gjj, axis=0)/len(Gjj)
        Gij_avg = np.sum(Gij, axis=0)/len(Gij)
        #### Fitting to a Gaussian ####
        sz1,sz2=Gij_avg.shape
        params_ii,covar_ii, num_ii = ics.fit_to_gaussian(Gii_avg)
        params_jj,covar_jj, num_jj = ics.fit_to_gaussian(Gjj_avg)
        params_ij,covar_ij, num_ij = ics.fit_to_gaussian(Gij_avg)

        #real_num_ij = (params_ij[0]/(params_ii[0]*params_jj[0]))*((sz1*sz2*0.05*0.05)/((np.pi*params_ij[1]**2)))
        real_num_ij = (params_ij[0]/(params_ii[0]*params_jj[0]))*((sz1*sz2*0.05*0.05)/(np.pi*((params_ij[1]**2 ))))
        fraction_i2ij = params_ij[0]/params_ii[0]
        fraction_j2ij = params_ij[0]/params_jj[0]
        print(f'Actual IJ = {real_num_ij}')
        ACF_ii_number.append(num_ii)
        ACF_jj_number.append(num_jj)
        CCF_ij_number.append(real_num_ij)
        frac_i_ij.append(fraction_i2ij)
        frac_j_ij.append(fraction_j2ij)
        # %%
    ics.box_plot_numbers(ACF_ii_number)
    ics.box_plot_numbers(ACF_jj_number)
    ics.box_plot_numbers(CCF_ij_number)
    ics.box_plot_numbers(frac_i_ij)
    ics.box_plot_numbers(frac_j_ij)
    number_path_ii = os.path.join(folder_save,"Number_ii.txt")
    number_path_jj = os.path.join(folder_save,"Number_jj.txt")
    number_path_ij = os.path.join(folder_save,"Number_ij.txt")
    frac_i_ij_path = os.path.join(folder_save,"frac_i2ij.txt")
    frac_j_ij_path = os.path.join(folder_save,"frac_j2ij.txt")
# Open the file in write mode
    with open(number_path_ii, 'w') as file:
        # Write each element of the list to the file
        for item in ACF_ii_number:
            file.write(str(item) + '\n')
    with open(number_path_jj, 'w') as file:
        # Write each element of the list to the file
        for item in ACF_jj_number:
            file.write(str(item) + '\n')
    with open(number_path_ij, 'w') as file:
        # Write each element of the list to the file
        for item in CCF_ij_number:
            file.write(str(item) + '\n')
    with open(frac_i_ij_path, 'w') as file:
        # Write each element of the list to the file
        for item in frac_i_ij:
            file.write(str(item) + '\n')
    with open(frac_j_ij_path, 'w') as file:
        # Write each element of the list to the file
        for item in frac_j_ij:
            file.write(str(item) + '\n')   

####### NOT BIG BATCH ######
else:
    if how_many == '1':
        folder_ch1 = askopenfilename(
            title="Please select the file to be opened (channel 1)")
        folder_ch2 = askopenfilename(
            title="Please select the file to be opened (channel 2)")
        savedirec = askdirectory(title="Where should the analysis be saved?")
        print(f'Files selected: \n Channel 1: {folder_ch1} \n Channel 2: {folder_ch2} \n \
              Saving the analysis to: {savedirec}')
        ims_oir_ch1 = [bioformats.load_image(folder_ch1, z=0, rescale=False)]
        ims_oir_ch2 = [bioformats.load_image(folder_ch2, z=0, rescale=False)]
    elif how_many == '2':
        folder = askdirectory(title='Select folder with data')
        print(f'Chosen data directory:   {folder}')
        folder_ch1 = os.path.join(folder, 'Channel 1')
        folder_ch2 = os.path.join(folder, 'Channel 2')
        # askdirectory(title='Where should the correlation functions and plots be saved?')
        savedirec = folder
        print(f'Folder selected:   {savedirec}')
        # folder_ch1 = askdirectory(title='Select folder with data for channel 1')
        # folder_ch2 = askdirectory(title='Select folder with data for channel 2')

        # print(f'Chosen data directory:   {folder_ch1}')
        # print(f'Chosen data directory:   {folder_ch2}')
        # Read in all the images with .oir or .tif file extensions
        # NOTE: If an image is in both of these formats it will be read in twice.

        ims_oir_ch1 = [bioformats.load_image(file,0) for file in glob.glob(os.path.join(folder_ch1,'*.oir'))]
        ims_oir_ch2 = [bioformats.load_image(file,1) for file in glob.glob(os.path.join(folder_ch2,'*.oir'))]
        ims_tif_ch1 = [bioformats.load_image(
            file, z=0, rescale=False) for file in glob.glob(os.path.join(folder_ch1, '*.tif'))]
        ims_tif_ch2 = [bioformats.load_image(
            file, z=0, rescale=False) for file in glob.glob(os.path.join(folder_ch2, '*.tif'))]
        # ims_tif_ch1 = [bioformats.load_image(file,t=0) for file in glob.glob(os.path.join(folder,'*.tif'))]
        # ims_tif_ch2 = [bioformats.load_image(file,t=1) for file in glob.glob(os.path.join(folder,'*.tif'))]
        # the (file,0) and (file,1) sections obtain channels 1 and 2 respectively.
        # .tif is, on occasion, read in through the time channel, hence t=0,1.

        # Add the tif images to the oir arrays (to save on lines of code later)
        ims_oir_ch1.extend(ims_tif_ch1)
        ims_oir_ch2.extend(ims_tif_ch2)

    N = len(ims_oir_ch1)
    M = len(ims_oir_ch2)
    if N != M:
        print(f'ERROR: The two channels do not have an equal number of images \
              Channel 1: {N} and Channel 2: {M}')
        exit()
    else:
        print(f'The number of pairs of images is {N},{M}')
    # Create a folder to add analysis to. To save time, this is just 'ICS_Analysis_x'
    # Where x is a number, if this is already taken this loops through until an unused
    # number is found.
    folder_number = 1
    saveto = os.path.join(savedirec, 'ICS_Analysis_'+str(folder_number))
    isdir = os.path.isdir(saveto)
    while isdir == True:
        folder_number += 1
        saveto = os.path.join(savedirec, 'ICS_Analysis_'+str(folder_number))
        isdir = os.path.isdir(saveto)
    os.mkdir(saveto)
    print(f'Saving analysis to:   {saveto}')

    # Get number of images (assumiming # ims in channel 1 = # ims in channel 2)

    # Display images
    for ii in range(0, int(N)):
        imgplot_oir_ch1 = plt.imshow(ims_oir_ch1[ii])
        plt.axis('off')
        plt.show()
        imgplot_oir_ch2 = plt.imshow(ims_oir_ch2[ii])
        plt.axis('off')
        plt.show()
    # %%
    # # Create lists for correlation functions
    # %%
    Gii = []
    Gjj = []
    Gij = []
    #Gji = []

    # %%
    # Compute correlation functions
    # %%
    for p in range(0, int(N)):
        channel_1 = ims_oir_ch1[p]# - ch1_bkgd_avg
        channel_2 = ims_oir_ch2[p]# - ch2_bkgd_avg

        Gii.append(ics.correlation_function(channel_1, channel_1))
        Gjj.append(ics.correlation_function(channel_2, channel_2))
        Gij.append(ics.correlation_function(channel_1, channel_2))
        #Gji.append(ics.correlation_function(channel_2, channel_1))

    # Averaging correlation functions #
    Gii_avg = np.sum(Gii, axis=0)/(len(Gii))
    Gjj_avg = np.sum(Gjj, axis=0)/len(Gjj)
    Gij_avg = np.sum(Gij, axis=0)/len(Gij)

    # %%
    # If there is anything in the array, save the correlation functions and plot them

    # %%
    ### Plotting ###
    if not len(Gii) == 0:
        folder_save = os.path.join(saveto, 'CFs')
        os.mkdir(folder_save)
        np.save(os.path.join(folder_save, 'Gii'), Gii)
        np.save(os.path.join(folder_save, 'Gjj'), Gjj)
        np.save(os.path.join(folder_save, 'Gij'), Gij)
        #np.save(os.path.join(folder_save,'Gji'), Gji)
        ics.plot_ccf(folder_save, Gii, 'Gii', cell)
        ics.plot_ccf(folder_save, Gjj, 'Gjj', cell)
        ics.plot_ccf(folder_save, Gij, 'Gij', cell)
        #ics.plot_ccf(folder_save, Gji,'Gji',cell)

    #### Fitting to a Gaussian ####
        # print("ACF ii")
        # params_ii,covar_ii, num_ii = ics.fit_to_gaussian(Gii_avg)
        # print("ACF jj")
        # params_jj,covar_jj, num_jj = ics.fit_to_gaussian(Gjj_avg)
        # print("CCF ij")
        # params_ij,covar_ij, num_ij = ics.fit_to_gaussian(Gij_avg)
        ## with ROI, comment out this or above
        print("ACF ii")
        params_ii,covar_ii, num_ii = ics.fit_to_gaussian(Gii_avg)
        print("ACF jj")
        params_jj,covar_jj, num_jj = ics.fit_to_gaussian(Gjj_avg)
        print("CCF ij")
        params_ij,covar_ij, num_ij = ics.fit_to_gaussian(Gij_avg)
        print(f'Number from ACF: Ch1 {num_ii} , Ch2 {num_jj}')
        #real_num_ij = params_ij[0]/(params_ii[0]*params_jj[0])
        real_num_ij = (params_ij[0]/(params_ii[0]*params_jj[0]))*((64*64*0.05*0.05)/((np.pi*params_ij[1]**2)))
        print(f'Actual number_ij = {real_num_ij}')
    # %%
