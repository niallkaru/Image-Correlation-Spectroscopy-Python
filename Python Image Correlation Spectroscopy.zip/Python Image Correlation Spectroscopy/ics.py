import numpy as np
import matplotlib.pyplot as plt
from matplotlib.pyplot import figure
import os
import scipy.optimize as opt
import scipy.fft as fft
import sys
from mpl_toolkits.mplot3d import Axes3D
from scipy.optimize import curve_fit
import scipy.stats as stats
import math
"""
Collection of functions to perform ICS on an image and fit the resultant
function to a Gaussian, amongst other things

The Gaussian fitting was based upon similar code by Sebastian Reinhard (Github)
Created Niall Karunaratne 2023
 
"""        
def one_or_many():
    """
    Does the user want to select a single image to analyse, or do they wish
    to run through an entire folder of images?
    :return: how_many, whether they want to select one or more images
    """
    allowed_values = ['1','2','3']
    
    choice = input("Please enter one of the following options: \n 1 for a single image \n 2 to load in a single folder of images \n 3 to analyse a directory of folders.\n")
    if any(x not in allowed_values for x in choice):
        print("Input not allowed")
        sys.exit()
    elif choice == '1':
        how_many = choice
    elif choice =='2':
        how_many = choice
    elif choice =='3':
        how_many = choice
    return how_many

# def gaussian_function(xy, g00, omega_o, g_inf,u,v):
#     xi, eta = xy
#     return g00 * np.exp(-((xi-u)**2 + (eta-v)**2) / omega_o**2) + g_inf

def gaussian_function(xy, g00, omega_o, g_inf):
    xi, eta = xy
    return g00 * np.exp(-((xi)**2 + (eta)**2) / omega_o**2) + g_inf

def fit_to_gaussian(data):
    d1,d2 = data.shape
    x = np.linspace(-1, 1, d1)
    y = np.linspace(-1, 1, d2)
    x, y = np.meshgrid(x, y)
    
    
    # Create xi and eta arrays
    xi = np.linspace(-1, 1, d1)
    eta = np.linspace(-1, 1, d2)
    xi, eta = np.meshgrid(xi, eta)
    
    # Flatten the data and coordinates for fitting
    xi_flat = xi.flatten()
    eta_flat = eta.flatten()
    data_flat = data.flatten()
    
    max_value = np.max(data)
    max_position = np.unravel_index(np.argmax(data), data.shape)
    target_value = max_value*math.exp(-2)
    target_index = None
    for index, value in np.ndenumerate(data):
        if math.isclose(value, target_value):
            target_index = index
            break
    # print("Maximum value:", max_value)
    # print("Maximum position (x, y):", max_position)
    # print("Target value (x * e^(-2)):", target_value)
    # print("Index of position with target value:", target_index)
    # Perform the fitting using curve_fit
    initial_guess = [data.max(), 0.02, 0]#,0,0]  # Initial parameter guess
    #initial_guess = [data.max()-data.min(), 0.02, data.min()]  # Initial parameter guess
    params, params_covariance = curve_fit(gaussian_function, (xi_flat, eta_flat), data_flat, p0=initial_guess)
    
    # Extract the fitted parameters
    g00_fit, omega_o_fit, g_inf_fit = params
    
    # Print the fitted parameters
    print("Fitted g(0,0):", g00_fit)
    print("Fitted omega_o:", omega_o_fit)
    
    # Evaluate the fit
    fit_data = gaussian_function((xi, eta), g00_fit, omega_o_fit, g_inf_fit)#,u,v)
    
    # Calculate the residuals
    residuals = data - fit_data
    
    # Calculate R-squared
    total_sum_of_squares = np.sum((data - np.mean(data))**2)
    residual_sum_of_squares = np.sum(residuals**2)
    r_squared = 1 - (residual_sum_of_squares / total_sum_of_squares)
    print("R-squared:", r_squared)
    
    # Calculate the chi-square statistic and p-value
    observed_frequencies, _ = np.histogram(data_flat, bins=10)  # Modify the number of bins as needed
    expected_frequencies = np.histogram(fit_data.flatten(), bins=10)[0]
    chi2, p_value = stats.chisquare(f_obs=observed_frequencies, f_exp=expected_frequencies)
    print("Chi-square statistic:", chi2)
    print("p-value:", p_value)
    
    # Calculate the area of the image
    px = 0.052 #um
    image_area_px = data.shape[0] * data.shape[1]
    image_area_um = image_area_px*(px**2)
    # Calculate the estimated number of foci
    N_per_beam = (np.pi * omega_o_fit**2 * g00_fit)
    N = image_area_um / N_per_beam
    
    print("Estimated number of foci:", N)
    
    # Plot original data, fitted data, and residuals
    fig, axes = plt.subplots(1, 3, figsize=(18, 4))
    
    # Plot original data
    axes[0].set_title('Original Data')
    im = axes[0].imshow(data, cmap='viridis', origin='lower')
    fig.colorbar(im, ax=axes[0], label='Data')
    
    # Plot fitted function
    axes[1].set_title('Fitted Function')
    im = axes[1].imshow(fit_data, cmap='viridis', origin='lower')
    fig.colorbar(im, ax=axes[1], label='Fit')
    
    # Plot residuals
    axes[2].set_title('Residuals')
    im = axes[2].imshow(residuals, cmap='bwr', origin='lower')
    fig.colorbar(im, ax=axes[2], label='Residual')
    
    # Set common labels
    for ax in axes:
        ax.set_xlabel('xi')
        ax.set_ylabel('eta')
    
    plt.tight_layout()
    plt.show()
    
    # Plot original data and fitted data in 3D
    fig_3d = plt.figure(figsize=(12, 6))
    ax3d = fig_3d.add_subplot(121, projection='3d')
    ax3d.set_title('Original Data (3D)')
    ax3d.plot_surface(x, y, data, cmap='viridis')
    ax3d.set_xlabel('x')
    ax3d.set_ylabel('y')
    
    ax3d_fit = fig_3d.add_subplot(122, projection='3d')
    ax3d_fit.set_title('Fitted Data (3D)')
    ax3d_fit.plot_surface(x, y, fit_data, cmap='viridis')
    ax3d_fit.set_xlabel('x')
    ax3d_fit.set_ylabel('y')
    plt.tight_layout()
    plt.show
    # Residuals - 3D plot
    fig_3d_res = plt.figure(figsize=(12, 6))
    ax3d_res = fig_3d_res.add_subplot(212, projection='3d')
    ax3d_res.set_title('Residuals')
    ax3d_res.plot_surface(xi, eta, residuals, cmap='viridis')
    ax3d_res.set_xlabel('xi')
    ax3d_res.set_ylabel('eta')
    ax3d_res.set_zlabel('Residual')
    plt.tight_layout()
    plt.show()
    return params, params_covariance, N
def fit_to_gaussian_roi(data):
    # Create xi and eta arrays
    d1,d2 = data.shape
    xi = np.linspace(-1, 1, d1)
    eta = np.linspace(-1, 1, d2)
    xi, eta = np.meshgrid(xi, eta)
    
    # Find the Gaussian centroid
    centroid_indices = np.unravel_index(np.argmax(data), data.shape)
    centroid_x, centroid_y = centroid_indices
    
    # Define the size of the ROI around the centroid
    roi_radius = 10  # Adjust the radius as needed
    
    # Create a mask for the region of interest (ROI)
    x_indices = np.arange(data.shape[0])
    y_indices = np.arange(data.shape[1])
    xx, yy = np.meshgrid(x_indices, y_indices)
    roi_mask = np.sqrt((xx - centroid_x)**2 + (yy - centroid_y)**2) <= roi_radius
    
    # Apply the ROI mask to the data, xi, and eta arrays
    data_roi = data[roi_mask]
    xi_roi = xi[roi_mask]
    eta_roi = eta[roi_mask]
    
    # Flatten the data and coordinates for fitting
    xi_flat = xi_roi.flatten()
    eta_flat = eta_roi.flatten()
    data_flat = data_roi.flatten()
    
    # Perform the fitting using curve_fit
    initial_guess = [data_roi.max(), 0.1, 0]  # Initial parameter guess
    params, params_covariance = curve_fit(gaussian_function, (xi_flat, eta_flat), data_flat, p0=initial_guess)
    
    # Extract the fitted parameters
    g00_fit, omega_o_fit, g_inf_fit = params
    
    # Print the fitted parameters
    print("Fitted g(0,0):", g00_fit)
    print("Fitted omega_o:", omega_o_fit)
    
    # Evaluate the fit
    fit_data = gaussian_function((xi, eta), g00_fit, omega_o_fit, g_inf_fit)
    
    # Calculate the residuals
    residuals = data - fit_data
    
    # Calculate R-squared
    total_sum_of_squares = np.sum((data - np.mean(data))**2)
    residual_sum_of_squares = np.sum(residuals**2)
    r_squared = 1 - (residual_sum_of_squares / total_sum_of_squares)
    print("R-squared:", r_squared)
    
    # # Calculate the observed and expected frequencies
    # num_bins = 10  # Number of bins for histogram
    # observed_counts, _ = np.histogram(data_flat, bins=num_bins, range=(0, num_bins-1))
    # expected_counts, _ = np.histogram(fit_data.flatten(), bins=num_bins, range=(0, num_bins-1))
    
    # # Print observed and expected frequencies for debugging
    # print("Observed frequencies:", observed_counts)
    # print("Expected frequencies:", expected_counts)
    
    # # Calculate the chi-square statistic and p-value
    # chi2, p_value = stats.chisquare(f_obs=observed_counts, f_exp=expected_counts)
    # print("Chi-square statistic:", chi2)
    # print("p-value:", p_value)
    
    # Calculate the area of the image
    px = 0.05
    image_area_px = data.shape[0] * data.shape[1]
    image_area_um = image_area_px*(px**2)
    # Calculate the estimated number of foci
    N = image_area_um / (np.pi * omega_o_fit**2 * g00_fit)
    
    print("Estimated number of foci:", N)
    
    # Plot original data, fitted data, and residuals
    fig, axes = plt.subplots(1, 3, figsize=(18, 4))
    
    # Plot original data
    axes[0].set_title('Original Data')
    im = axes[0].imshow(data, cmap='viridis', origin='lower')
    fig.colorbar(im, ax=axes[0], label='Data')
    
    # Plot fitted function
    axes[1].set_title('Fitted Function')
    im = axes[1].imshow(fit_data, cmap='viridis', origin='lower')
    fig.colorbar(im, ax=axes[1], label='Fit')
    
    # Plot residuals
    axes[2].set_title('Residuals')
    im = axes[2].imshow(residuals, cmap='bwr', origin='lower')
    fig.colorbar(im, ax=axes[2], label='Residual')
    
    # Set common labels
    for ax in axes:
        ax.set_xlabel('xi')
        ax.set_ylabel('eta')
    
    plt.tight_layout()
    plt.show()
    
    # # Plot original data and fitted data in 3D
    # fig_3d = plt.figure(figsize=(12, 6))
    # ax3d = fig_3d.add_subplot(121, projection='3d')
    # ax3d.set_title('Original Data (3D)')
    # ax3d.plot_surface(x, y, data, cmap='viridis')
    # ax3d.set_xlabel('x')
    # ax3d.set_ylabel('y')
    
    # ax3d_fit = fig_3d.add_subplot(122, projection='3d')
    # ax3d_fit.set_title('Fitted Data (3D)')
    # ax3d_fit.plot_surface(x, y, fit_data, cmap='viridis')
    # ax3d_fit.set_xlabel('x')
    # ax3d_fit.set_ylabel('y')
    # plt.tight_layout()
    # plt.show()
    
    # Residuals - 3D plot
    fig_3d_res = plt.figure(figsize=(12, 6))
    ax3d_res = fig_3d_res.add_subplot(212, projection='3d')
    ax3d_res.set_title('Residuals')
    ax3d_res.plot_surface(xi, eta, residuals, cmap='viridis')
    ax3d_res.set_xlabel('xi')
    ax3d_res.set_ylabel('eta')
    ax3d_res.set_zlabel('Residual')
    plt.tight_layout()
    plt.show()
    return params, params_covariance, N

def apply_hamming_window(image):
    """Apply a Hamming window to an image (if desired) to counter edge effects"""
    window_h = np.hamming(image.shape[0])
    window_v = np.hamming(image.shape[1])
    image = np.multiply(image.T, window_h).T
    return np.multiply(image, window_v)

def correlation_function(image1, image2):
    """
    Compute power spectrum via FFT to get the correlation function. FFTs make
    this much faster for ICS. Both methods are coded here, performing Fourier
    transforms on the images themselves, and Fourier transforms on the spatial
    fluctuations (value-mean). Both get the same result, but through slightly
    different methods
    :parameter image1: The first image, normally in channel 1, to be correlated
    :parameter image2: The second image, normally from channel 2, to be correlated
    :return: cf correlation function of the two images
    """
    ## Shared between methods ##
    # ft_im1 = fft.fft2(apply_hamming_window(image1))
    # ft_im2 = fft.fft2(apply_hamming_window(image2))
    x,y = image1.shape
    u,v = image2.shape

    mean_im1 = np.mean(image1)
    mean_im2 = np.mean(image2)
    # image1 = apply_hamming_window(image1)
    # image2 = apply_hamming_window(image2)
    ## Fourier on images ##
    ft_im1 = fft.fft2(image1)
    ft_im2 = fft.fft2(image2)
    
    ## Fourier on fluctuations ##

    matrix_mean_im1 = np.ones((x,y))*mean_im1
    matrix_mean_im2 = np.ones((u,v))*mean_im2
    im1_fluc = image1 - matrix_mean_im1
    im2_fluc = image2 - matrix_mean_im2
    ft_im1_fluc = fft.fft2((im1_fluc))
    ft_im2_fluc = fft.fft2((im2_fluc))
    
    ## Calculation ##
    #cf = (fft.fftshift(np.real(fft.ifft2(ft_im1_fluc*np.conj(ft_im2_fluc)))))/(mean_im1*mean_im2*x*y)
    cf = ((fft.fftshift(np.real(fft.ifft2(ft_im1*np.conj(ft_im2)))))/(mean_im1*mean_im2*x*y)) -1
   
  
    return cf

def brute_cross_correlation(image1, image2):
    """
    Calculate the cross-correlation (or autocorrelation) using the original definition
    of a correlation function, i.e. integrals. Do not use this for most applications,
    as fast Fourier transforms (FFTs) outperform direct calculation.
    This function was created to showcase the advantage of FFTs.
    :parameter image1: The first image, normally in channel 1, to be correlated
    :parameter image2: The second image, normally from channel 2, to be correlated
    :return: cf_integral correlation function of the two images calculated directly with integrals
    """
    mean_im1 = np.mean(image1)
    mean_im2 = np.mean(image2)
    x1,y1 = image1.shape
    print(f'Channel Dimensions {x1,y1}')
    N = x1*y1
    x2,y2 = image2.shape
    M = x2*y2
    cf_integral = np.zeros([x1,y1])
    for h in range(len(image1)):    
         image_a = image1
         image_b = image2
         for i in range(0,y1):
             for j in range(0,x1):
                 v = image_a[j,i]
                 w = v*image_b
                 c = np.sum(w)
                 den = mean_im1*mean_im2*N*M
                 g = (c/(den)) -1
                 cf_integral[j,i] = g
                 #print(f'cf_sum_num {c}, cf_sum_den {den}, value at array position {cf_integral[j,i]}')
    return cf_integral

def box_plot_numbers(data):
    
    # Sample data for the box plot
    
    # Create a figure and axis
    fig, ax = plt.subplots()
    
    # Create the box plot
    ax.boxplot(data)
    
    # Set labels and title
    ax.set_xticklabels(['Boxplot'])
    ax.set_ylabel('Values')
    ax.set_title('Box Plot Example')
    
    # Display the plot
    plt.show()
def plot_ccf(folder, array, name,cell):
    """
    Function to plot correlation functions
    :parameter folder: folder to save to
    :parameter array: the array containing the correlation functions
    :parameter name: the name of the array used
    :return: returns nothing
    """
    # Find the maxima and minima for plotting (avoid autoscaling, which leads to
    # misleading plots).
    z = len(array)
    array_maxima = []
    array_minima = []
    for j in range(0, int(z)):
        h = array[j]
        array_maxima.append(np.nanmax(h))
        array_minima.append(np.nanmin(h))
        
    max_val = np.nanmax(array_maxima) 
    min_val = np.nanmin(array_minima)
    #print(max_val, min_val)
    # Get the name of the array for saving the array
    path = os.path.join(folder,'Plots_'+name)
    exists_path = os.path.isdir(path)
    if exists_path == False:
        os.mkdir(path)

    
    ##For Multiple CFs in matrix

    #print("The number of sets of images to be plotted : ",z) #Number of images
    
    for i in range(0,int(z)):
        a = array[i]
        # Extract data for each CCF from wider array
        colour = 'binary_r' #Choose colourmap; rgb = 'jet', b&w = 'gray' or 'binary_r'

        px = 1/(plt.rcParams['figure.dpi'])  # pixel in inches
        figure(figsize=(60*px,61.5*px), dpi=100)
        
        plt.pcolormesh(a,cmap = colour, vmin=min_val, vmax=max_val)
        # plt.title(f'Plot {name} _ {i+1}',fontsize = 8) #Comment this line out if giving plots to ML
        # ax.set_xlabel(r'$\xi$')
        # ax.set_ylabel(r'$\eta$')
        plt.axis('off')
        
        # Saving
        filename = 'Plot_'+name+'_'+cell+'_'+str(i+1)
        fullfile = os.path.join(path, filename)
        plt.savefig(fullfile +'.tif', bbox_inches='tight', pad_inches=0)
        
        # Set to square, plot, switch of axis and save as .tiff
        plt.show()
        plt.close()
        # Close to allow loop to repeat for new plot



