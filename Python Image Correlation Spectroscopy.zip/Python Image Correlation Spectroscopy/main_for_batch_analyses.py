# -*- coding: utf-8 -*-
"""
Created on Wed Mar 29 15:58:52 2023

@author: niall

Main file to perform image correlation spectroscopy (ICS) on images. The code
can take in images from .oir and .tif files, but if another format is required
that is supported by bioformats it can be changed easily. 

The code can either take in raw images, or it can take in RoIs, but this must
be chosen by commenting or uncommenting lines of code.

The code will output an image of the cells (one for each channel), the 
autocorrelations for each channel and the cross-correlation between them. It 
will also output a Gaussian fit.
"""
import ics
import numpy as np
from tkinter.filedialog import askdirectory
import os
import javabridge
import bioformats
import matplotlib.pyplot as plt
import glob
from pathlib import Path

###### READING IN IMAGES AND MAKING FOLDERS ######
# %%
myloglevel="ERROR"  # user string argument for logLevel.

javabridge.start_vm(class_path=bioformats.JARS) # Start the virtual machine
## The following four lines stop the virtual machine from spitting out
## a huge amount of debugging info into the console, comment them out or delete if you want this
rootLoggerName = javabridge.get_static_field("org/slf4j/Logger","ROOT_LOGGER_NAME", "Ljava/lang/String;")
rootLogger = javabridge.static_call("org/slf4j/LoggerFactory","getLogger", "(Ljava/lang/String;)Lorg/slf4j/Logger;", rootLoggerName)
logLevel = javabridge.get_static_field("ch/qos/logback/classic/Level",myloglevel, "Lch/qos/logback/classic/Level;")
javabridge.call(rootLogger, "setLevel", "(Lch/qos/logback/classic/Level;)V", logLevel)

# Choose what data to analyse and where to save the analysis
big_direc = askdirectory(title='Where is all the stuff?')

saveto = os.path.join(big_direc,'ICS_Analysis_D1521R')#+str(folder_number))
os.mkdir(saveto)
folder_save = os.path.join(saveto,'CFs')
os.mkdir(folder_save)
for folder in glob.glob(big_direc+"/*", recursive = True):
    
    print(f'Chosen data directory:   {folder}')
    # folder_ch1 = askdirectory(title='Select folder with data for channel 1') 
    # print(f'Chosen data directory:   {folder_ch1}')
    # folder_ch2 = askdirectory(title='Select folder with data for channel 2') 
    # print(f'Chosen data directory:   {folder_ch2}')
    folder_ch1 = os.path.join(folder,'Channel 1')
    folder_ch2 = os.path.join(folder,'Channel 2')
    savedirec = big_direc #askdirectory(title='Where should the correlation functions and plots be saved?')
    print(f'Folder selected:   {savedirec}')
    
    #Create a folder to add analysis to. To save time, this is just 'ICS_Analysis_x'
    # Where x is a number, if this is already taken this loops through until an unused
    # number is found.
    folder_number = 1
    # saveto = os.path.join(savedirec,'ICS_Analysis_L1619A')#+str(folder_number))
    # isdir = os.path.isdir(saveto)
    # while isdir == True:
    #     folder_number += 1
    #     saveto = os.path.join(savedirec,'ICS_Analysis_L1619A')#+str(folder_number))
    #     isdir = os.path.isdir(saveto)
    #os.mkdir(saveto)
    print(f'Saving analysis to:   {saveto}')
    
    
    # ims_oir_ch1 = bioformats.load_image('53bp1_gh2ax_010423_1.oir',0)
    # Read in all the images with .oir or .tif file extensions
    # NOTE: If an image is in both of these formats it will be read in twice.
    
    # ims_oir_ch1 = [bioformats.load_image(file,0) for file in glob.glob(os.path.join(folder,'*.oir'))]
    # ims_oir_ch2 = [bioformats.load_image(file,1) for file in glob.glob(os.path.join(folder,'*.oir'))]
    ims_oir_ch1 = [bioformats.load_image(file,0) for file in glob.glob(os.path.join(folder_ch1,'*.tif'))]
    ims_oir_ch2 = [bioformats.load_image(file,0) for file in glob.glob(os.path.join(folder_ch2,'*.tif'))]
    # ims_tif_ch1 = [bioformats.load_image(file,t=0) for file in glob.glob(os.path.join(folder,'*.tif'))]
    # ims_tif_ch2 = [bioformats.load_image(file,t=1) for file in glob.glob(os.path.join(folder,'*.tif'))]
    #the (file,0) and (file,1) sections obtain channels 1 and 2 respectively.
    #.tif is, on occasion, read in through the time channel, hence t=0,1.
    
    # Add the tif images to the oir arrays (to save on lines of code later)
    # ims_oir_ch1.extend(ims_tif_ch1)
    # ims_oir_ch2.extend(ims_tif_ch2)
    #Get number of images (assumiming # ims in channel 1 = # ims in channel 2)
    N = len(ims_oir_ch1)
    M = len(ims_oir_ch2)
    print(f'The number of image pairs is {N},{M}')
    if N != M:
        print(f'The two channels do not have an equal number of images')
        exit()
    
    #Display images
    for ii in range(0,int(N)):
        imgplot_oir_ch1 = plt.imshow(ims_oir_ch1[ii])
        plt.axis('off')
        plt.show()
        imgplot_oir_ch2 = plt.imshow(ims_oir_ch2[ii]) 
        plt.axis('off')
        plt.show()
    # %%
    # # Create lists for correlation functions
    # %%
    Gii = []
    Gjj = []
    Gij = []
    #Gji = []
    
    
    # %%
    #Compute correlation functions
    #%%
    for p in range(0,int(N)):
        channel_1 = ims_oir_ch1[p]
        channel_2 = ims_oir_ch2[p]
        # a,b = channel_1.shape
        # c,d = channel_2.shape
        # print(f'a,b {a,b} ; c,d {c,d}')
        
        Gii.append(ics.correlation_function(channel_1, channel_1))
        Gjj.append(ics.correlation_function(channel_2, channel_2))
        Gij.append(ics.correlation_function(channel_1, channel_2))
        #Gji.append(ics.correlation_function(channel_2, channel_1))
    
    
    #%% 
    ### If there is anything in the array, save the correlation functions and plot them
    
    #%%
    ### Plotting ###
    if not len(Gii) == 0:

        image_name = Path(folder).stem
        print(f'Image: {image_name}')
        print("\n")
        np.save(os.path.join(folder_save, 'Gii_'+image_name), Gii)
        np.save(os.path.join(folder_save,'Gjj_'+image_name), Gjj)
        np.save(os.path.join(folder_save,'Gij_'+image_name), Gij)
        #np.save(os.path.join(folder_save,'Gji'), Gji)
        ics.plot_ccf(folder_save, Gii,'Gii',image_name)
        ics.plot_ccf(folder_save, Gjj,'Gjj',image_name)
        ics.plot_ccf(folder_save, Gij,'Gij',image_name)
        #ics.plot_ccf(folder_save, Gji,'Gji')
        
    #### Fitting to a Gaussian ####
        # print(f'ACF ii')
        # for gg in range(len(Gii)):
        #     ics.fit_to_gaussian_old(Gii[gg],f'Gii {gg}')
        # print(f'ACF jj')
        # for hh in range(len(Gjj)):
        #     ics.fit_to_gaussian_old(Gjj[hh],f'Gjj {hh}')
        # print(f'CCF ij')
        # for ll in range(len(Gij)):
        #     ics.fit_to_gaussian_old(Gij[ll],f'Gij {ll}')
        #     #ics.fit_to_gaussian(Gji[gg])
        
    #%%
    
    
    
    
#javabridge.kill_vm(class_path=bioformats.JARS) # Close javabridge